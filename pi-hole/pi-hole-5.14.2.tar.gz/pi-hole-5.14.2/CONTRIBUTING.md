# Contributors Guide

Please read and understand the contribution guide before creating an issue or pull request.

The guide can be found here: [https://docs.pi-hole.net/guides/github/contributing/](https://docs.pi-hole.net/guides/github/contributing/)
