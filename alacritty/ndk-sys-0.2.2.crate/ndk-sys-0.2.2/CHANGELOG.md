# Unreleased

# 0.2.2 (2021-11-16)

- Regenerate against NDK r23 (#178)

# 0.2.1 (2020-10-15)

- Fix documentation build on docs.rs

# 0.2.0 (2020-09-15)

- **Breaking:** `onSaveInstanceState` signature corrected to take `outSize` as a `*mut size_t` instead of `*mut usize`.
- Add `media` bindings
- Add `bitmap` and `hardware_buffer` bindings
- Add `aaudio` bindings

# 0.1.0 (2020-04-22)

- Initial release! 🎉
