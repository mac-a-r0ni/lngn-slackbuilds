use wasm_bindgen::prelude::*;

#[wasm_bindgen(nonsense)]
pub fn foo() {}

fn main() {}
