use crate::buffer::CVBufferRef;

pub type CVImageBufferRef = CVBufferRef;
