// C++ compilation harness for the test suite.
//
// This is used to ensure the Expat headers can be included from C++
// and have everything work as expected.
//
#include "runtests.c"
