spsc-buffer
===================

Simple lock-free single-producer single-consumer buffer using a single atomic.
