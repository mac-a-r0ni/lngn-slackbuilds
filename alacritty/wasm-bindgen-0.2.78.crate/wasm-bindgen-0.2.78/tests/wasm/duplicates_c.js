exports.foo = () => false;
exports.bar = 5;
