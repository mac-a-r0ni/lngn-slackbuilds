This directory contains test programs compatible with [libFuzzer][libfuzzer],
a library for coverage-guided fuzz testing.

[libfuzzer]: https://llvm.org/docs/LibFuzzer.html
