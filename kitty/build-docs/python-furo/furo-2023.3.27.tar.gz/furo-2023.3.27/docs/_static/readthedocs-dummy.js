var READTHEDOCS_DATA = {
  project: "furo",
  version: "latest",
  language: "en",
  proxied_api_host: "https://readthedocs.org",
  features: {
    docsearch_disabled: true,
  },
};
