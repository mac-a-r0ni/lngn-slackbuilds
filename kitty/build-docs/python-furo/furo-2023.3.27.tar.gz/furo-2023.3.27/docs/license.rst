=======
License
=======

**MIT License**

.. include:: ../LICENSE
