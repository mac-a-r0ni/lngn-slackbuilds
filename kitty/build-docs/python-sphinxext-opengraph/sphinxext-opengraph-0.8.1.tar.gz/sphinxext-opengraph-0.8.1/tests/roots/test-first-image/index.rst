.. image:: http://example.org/en/latest/image2.png
   :alt: Test image alt text