extensions = ["sphinxext.opengraph"]

master_doc = "index"
exclude_patterns = ["_build"]

html_theme = "basic"

smartquotes = False

ogp_site_url = "http://example.org/en/latest/"
