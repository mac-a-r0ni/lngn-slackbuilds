```{include} ../../README.md
:relative-images:
:relative-docs: docs/source
```

```{toctree}
:hidden:
socialcards
```
