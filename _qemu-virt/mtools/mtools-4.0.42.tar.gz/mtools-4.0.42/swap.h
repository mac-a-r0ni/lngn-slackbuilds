Stream_t *OpenSwap(Stream_t *Next);

