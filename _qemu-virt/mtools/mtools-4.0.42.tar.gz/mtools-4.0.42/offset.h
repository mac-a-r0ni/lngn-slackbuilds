Stream_t *OpenOffset(Stream_t *Next, struct device *dev, off_t offset,
		     char *errmsg, mt_off_t *maxSize);
