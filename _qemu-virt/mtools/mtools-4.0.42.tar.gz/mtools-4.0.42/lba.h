int compute_lba_geom_from_tot_sectors(struct device *dev);
