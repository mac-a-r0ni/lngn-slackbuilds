#pragma once

#include <string>
#include "ListItem.h"

/*******************************************************************************

List item that describes a group of SlackBuilds

*******************************************************************************/
class CategoryListItem: public ListItem {

  public:

    // Constructor

    CategoryListItem();
};
