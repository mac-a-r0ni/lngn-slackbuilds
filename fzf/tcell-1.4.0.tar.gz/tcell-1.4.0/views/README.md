## tcell views

This package provides some enhanced functionality on top of base tcell.
In particular, support for logical views, and a few different kinds of
widgets like title bars, and scrollable areas, are provided.

These make up a higher level interface than tcell itself.
