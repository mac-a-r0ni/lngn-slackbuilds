# This work is licensed under the GNU GPLv2 or later.
# See the COPYING file in the top-level directory.

import gi

gi.require_version("Gdk", "3.0")
gi.require_version("Gtk", "3.0")
