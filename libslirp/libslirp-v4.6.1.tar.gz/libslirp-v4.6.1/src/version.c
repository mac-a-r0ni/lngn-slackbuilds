/* SPDX-License-Identifier: BSD-3-Clause */
#include "libslirp.h"

const char *
slirp_version_string(void)
{
    return SLIRP_VERSION_STRING;
}
